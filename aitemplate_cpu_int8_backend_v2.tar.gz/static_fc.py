# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# Licensed under the Apache License, Version 2.0.

"""Helpers for persistent CPU XNNPACK static-FC caches."""

import os


def cache_id_from_tensor_name(name: str) -> int:
    """Return a deterministic non-zero 64-bit cache id for a tensor name."""

    # FNV-1a 64-bit.  We embed the result as a literal in generated C++,
    # so Python's randomized hash() must not be used here.
    value = 14695981039346656037

    for byte in name.encode("utf-8"):
        value ^= byte
        value = (value * 1099511628211) & 0xFFFFFFFFFFFFFFFF

    return value or 1


def use_int8_static_fc() -> bool:
    """Return whether generated CPU static FC kernels should use INT8.

    This is evaluated at AITemplate compile/codegen time. The generated model
    therefore contains one FC representation only: the existing FP32 path by
    default, or dynamic-QD8/QC8W when AIT_CPU_INT8_FC=1.
    """

    value = os.environ.get("AIT_CPU_INT8_FC", "0").strip().lower()
    return value in {"1", "true", "yes", "on"}
