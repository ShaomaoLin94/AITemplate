# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# Licensed under the Apache License, Version 2.0.

"""Backend overlay for fused gemm_rcr_bias_add + LayerNorm."""

from collections import OrderedDict
from typing import Any, Dict

import jinja2

from aitemplate.backend import registry
from aitemplate.backend.cpu.gemm_universal.gemm_rcr_bias import (
    _dim_expr,
)
from aitemplate.backend.cpu.gemm_universal.gemm_rcr_bias_add import (
    _needs_input_scratch,
)
from aitemplate.backend.cpu.gemm_universal.static_fc import (
    cache_id_from_tensor_name,
    use_int8_static_fc,
)
from aitemplate.compiler.base import IntImm
from aitemplate.compiler.dtype import normalize_dtype


_BASE_CONFIG = registry.get(
    "cpu.gemm_rcr_bias_add.config"
)
_BASE_GEN_PROFILER = registry.get(
    "cpu.gemm_rcr_bias_add.gen_profiler"
)
_BASE_GEN_FUNCTION = registry.get(
    "cpu.gemm_rcr_bias_add.gen_function"
)
_BASE_FUNC_DECL = registry.get(
    "cpu.gemm_rcr_bias_add.func_decl"
)
_BASE_FUNC_CALL = registry.get(
    "cpu.gemm_rcr_bias_add.func_call"
)


def _is_fused(func_attrs):
    return bool(
        func_attrs.get(
            "fused_layernorm",
            False,
        )
    )


def _static_int(dim):
    if not isinstance(dim, IntImm):
        raise NotImplementedError(
            "CPU fused residual LayerNorm "
            "currently requires static N"
        )

    return dim.value()


def _validate_fused(func_attrs):
    if len(func_attrs["inputs"]) != 6:
        raise NotImplementedError(
            "Fused gemm_rcr_bias_add+layernorm "
            "requires A, B, bias, residual, gamma, beta"
        )

    a, b, bias, residual, gamma, beta = (
        func_attrs["inputs"]
    )

    for tensor in (
        a,
        b,
        bias,
        residual,
        gamma,
        beta,
        func_attrs["outputs"][0],
    ):
        if normalize_dtype(
            tensor._attrs["dtype"]
        ) != "float32":
            raise NotImplementedError(
                "CPU fused residual LayerNorm "
                "currently supports float32 only"
            )

    n = _static_int(
        b._attrs["shape"][0]
    )

    if (
        len(gamma._attrs["shape"]) != 1
        or _static_int(
            gamma._attrs["shape"][0]
        )
        != n
    ):
        raise NotImplementedError(
            "gamma must have shape [N]"
        )

    if (
        len(beta._attrs["shape"]) != 1
        or _static_int(
            beta._attrs["shape"][0]
        )
        != n
    ):
        raise NotImplementedError(
            "beta must have shape [N]"
        )

    normalized_shape = func_attrs.get(
        "normalized_shape"
    )

    if (
        normalized_shape is None
        or len(normalized_shape) != 1
        or _static_int(normalized_shape[0])
        != n
    ):
        raise NotImplementedError(
            "LayerNorm normalized_shape must be [N]"
        )


FUNC_SIGNATURE = jinja2.Template(
    """
void {{func_name}}(
    const void* a,
    const void* b,
    const void* bias,
    const void* residual,
    const void* gamma,
    const void* beta,
    void* output,
    size_t m,
    size_t n,
    size_t k,
    uint64_t cache_id,
    bool use_input_scratch,
    float eps,
    ait::StreamType stream)
"""
)


FUNC_DECL = jinja2.Template(
    """
{{func_signature}};
"""
)


FUNC_CALL = jinja2.Template(
    """
{{indent}}{{func_name}}(
{{indent}}    {{a}},
{{indent}}    {{b}},
{{indent}}    {{bias}},
{{indent}}    {{residual}},
{{indent}}    {{gamma}},
{{indent}}    {{beta}},
{{indent}}    {{output}},
{{indent}}    {{m}},
{{indent}}    {{n}},
{{indent}}    {{k}},
{{indent}}    {{cache_id}},
{{indent}}    {{use_input_scratch}},
{{indent}}    {{eps}},
{{indent}}    stream);
"""
)


FUNC_TEMPLATE = jinja2.Template(
    r"""
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <limits>
#include <list>
#include <stdexcept>
#include <string>
#include <vector>

#include <xnnpack.h>

#include "device_functions-generated.h"
#include "cpu_threadpool.h"
#include "model_interface.h"

namespace {

inline void {{func_name}}_check_xnn_status(
    xnn_status status,
    const char* step) {

  if (status != xnn_status_success) {
    throw std::runtime_error(
        std::string(step) +
        " failed with XNNPACK status " +
        std::to_string(
            static_cast<int>(status)));
  }
}


static constexpr bool {{func_name}}_use_int8_static_fc =
    {{use_int8}};


struct {{func_name}}_xnn_context {
  xnn_operator_t op = nullptr;

  uint64_t cache_id = 0;
  const float* weight_ptr = nullptr;
  const float* bias_ptr = nullptr;

  size_t cached_m = 0;
  size_t n = 0;
  size_t k = 0;

  // Optional dynamic-QD8 INT8 path. These members are unused in FP32 builds.
  xnn_operator_t int8_fc_op = nullptr;
  xnn_operator_t int8_convert_op = nullptr;

  // Keep quantized static weights/scales alive for the lifetime of the
  // XNNPACK operator. This is deliberately conservative and avoids relying
  // on undocumented packing timing during create/reshape.
  std::vector<int8_t> int8_weight;
  std::vector<float> int8_weight_scale;

  // Per-context activation quantization storage. m is static for BERT, so
  // these buffers allocate on the first reshape and are reused thereafter.
  std::vector<int8_t> int8_input;
  std::vector<xnn_quantization_params> int8_qparams;
  std::vector<uint8_t> int8_workspace_storage;
  size_t int8_workspace_size = 0;

  {{func_name}}_xnn_context(
      uint64_t id,
      const float* weight,
      const float* bias,
      size_t output_channels,
      size_t input_channels)
      : cache_id(id),
        weight_ptr(weight),
        bias_ptr(bias),
        n(output_channels),
        k(input_channels) {

    if constexpr ({{func_name}}_use_int8_static_fc) {
      int8_weight.resize(n * k);
      int8_weight_scale.resize(n);

      // Static per-output-channel symmetric INT8 weight quantization.
      // n/k are taken from the compiled operator, so this is equally valid
      // for BERT-base (768/3072) and BERT-large (1024/4096).
      for (size_t oc = 0; oc < n; ++oc) {
        const float* weight_row =
            weight_ptr + oc * k;

        float max_abs = 0.0f;
        for (size_t ic = 0; ic < k; ++ic) {
          max_abs = std::max(
              max_abs,
              std::abs(weight_row[ic]));
        }

        const float scale =
            max_abs > 0.0f
                ? max_abs / 127.0f
                : 1.0f;

        int8_weight_scale[oc] = scale;
        int8_t* qrow =
            int8_weight.data() + oc * k;

        for (size_t ic = 0; ic < k; ++ic) {
          int value = static_cast<int>(
              std::nearbyint(
                  weight_row[ic] / scale));

          value = std::max(
              -127,
              std::min(127, value));

          qrow[ic] =
              static_cast<int8_t>(value);
        }
      }

      {{func_name}}_check_xnn_status(
          xnn_create_convert_nc_f32_qd8(
              0,
              &int8_convert_op),
          "xnn_create_convert_nc_f32_qd8");

      {{func_name}}_check_xnn_status(
          xnn_create_fully_connected_nc_qd8_f32_qc8w(
              k,
              n,
              k,
              n,
              int8_weight_scale.data(),
              int8_weight.data(),
              bias_ptr,
              -std::numeric_limits<float>::infinity(),
              +std::numeric_limits<float>::infinity(),
              0,
              nullptr,
              &int8_fc_op),
          "xnn_create_fully_connected_nc_qd8_f32_qc8w");
    } else {
          {{func_name}}_check_xnn_status(
              xnn_create_fully_connected_nc_f32(
                  k,
                  n,
                  k,
                  n,
                  weight_ptr,
                  bias_ptr,
                  -std::numeric_limits<float>::infinity(),
                  +std::numeric_limits<float>::infinity(),
                  0,
                  nullptr,
                  &op),
              "xnn_create_fully_connected_nc_f32");
    }

  }

  ~{{func_name}}_xnn_context() {
    if (op != nullptr) {
      xnn_delete_operator(op);
    }

    if (int8_fc_op != nullptr) {
      xnn_delete_operator(int8_fc_op);
    }

    if (int8_convert_op != nullptr) {
      xnn_delete_operator(int8_convert_op);
    }
  }

  bool matches(
      uint64_t id,
      size_t output_channels,
      size_t input_channels) const {

    return cache_id == id &&
           n == output_channels &&
           k == input_channels;
  }

  void* int8_workspace_ptr() {
    if (int8_workspace_size == 0) {
      return nullptr;
    }

    constexpr uintptr_t kAlignment = 64;
    const uintptr_t raw =
        reinterpret_cast<uintptr_t>(
            int8_workspace_storage.data());
    const uintptr_t aligned =
        (raw + kAlignment - 1) &
        ~(kAlignment - 1);

    return reinterpret_cast<void*>(aligned);
  }

  void run_int8(
      const float* input,
      float* output) {
    {{func_name}}_check_xnn_status(
        xnn_setup_convert_nc_f32_qd8(
            int8_convert_op,
            input,
            int8_input.data(),
            nullptr,
            int8_qparams.data()),
        "xnn_setup_convert_nc_f32_qd8");

    {{func_name}}_check_xnn_status(
        xnn_run_operator(
            int8_convert_op,
            ait::cpu_threadpool()),
        "xnn_run_operator(convert_f32_qd8)");

    {{func_name}}_check_xnn_status(
        xnn_setup_fully_connected_nc_qd8_f32_qc8w(
            int8_fc_op,
            int8_input.data(),
            output,
            int8_workspace_ptr(),
            int8_qparams.data()),
        "xnn_setup_fully_connected_nc_qd8_f32_qc8w");

    {{func_name}}_check_xnn_status(
        xnn_run_operator(
            int8_fc_op,
            ait::cpu_threadpool()),
        "xnn_run_operator(fully_connected_qd8_qc8w)");
  }

  void reshape(size_t m) {
    if (cached_m == m) {
      return;
    }

    if constexpr ({{func_name}}_use_int8_static_fc) {
      const size_t logical_elements = m * k;

      int8_input.resize(
          logical_elements + XNN_EXTRA_BYTES);
      std::fill(
          int8_input.begin() + logical_elements,
          int8_input.end(),
          static_cast<int8_t>(0));

      int8_qparams.resize(
          m + XNN_EXTRA_QUANTIZATION_PARAMS);

      {{func_name}}_check_xnn_status(
          xnn_reshape_convert_nc_f32_qd8(
              int8_convert_op,
              m,
              k,
              k,
              k,
              ait::cpu_threadpool()),
          "xnn_reshape_convert_nc_f32_qd8");

      size_t workspace_size = 0;
      {{func_name}}_check_xnn_status(
          xnn_reshape_fully_connected_nc_qd8_f32_qc8w(
              int8_fc_op,
              m,
              &workspace_size,
              ait::cpu_threadpool()),
          "xnn_reshape_fully_connected_nc_qd8_f32_qc8w");

      int8_workspace_size = workspace_size;
      if (workspace_size == 0) {
        int8_workspace_storage.clear();
      } else {
        int8_workspace_storage.resize(
            workspace_size + 63);
      }
    } else {
          {{func_name}}_check_xnn_status(
              xnn_reshape_fully_connected_nc_f32(
                  op,
                  m,
                  ait::cpu_threadpool()),
              "xnn_reshape_fully_connected_nc_f32");
    }


    cached_m = m;
  }

  {{func_name}}_xnn_context(
      const {{func_name}}_xnn_context&) = delete;

  {{func_name}}_xnn_context& operator=(
      const {{func_name}}_xnn_context&) = delete;
};


struct {{func_name}}_xnn_cache {
  std::list<{{func_name}}_xnn_context> contexts;

  {{func_name}}_xnn_context& get(
      uint64_t cache_id,
      const float* weight,
      const float* bias,
      size_t m,
      size_t n,
      size_t k) {

    for (auto& context : contexts) {
      if (context.matches(
              cache_id,
              n,
              k)) {
        context.reshape(m);
        return context;
      }
    }

    if (
        weight == nullptr ||
        bias == nullptr
    ) {
      throw std::runtime_error(
          "CPU static FC cache miss after "
          "raw weight release");
    }

    contexts.emplace_back(
        cache_id,
        weight,
        bias,
        n,
        k);

    auto& context = contexts.back();

    context.reshape(m);

    return context;
  }
};


thread_local {{func_name}}_xnn_cache
    {{func_name}}_fc_cache;


struct {{func_name}}_layernorm_context {
  const float* residual;
  const float* gamma;
  const float* beta;
  float* output;

  size_t n;
  float eps;
};


void {{func_name}}_layernorm_row(
    void* raw_context,
    size_t row) {

  auto* context =
      static_cast<
          {{func_name}}_layernorm_context*>(
              raw_context);

  const size_t offset =
      row * context->n;

  float* output_row =
      context->output + offset;

  const float* residual_row =
      context->residual + offset;

  double sum = 0.0;
  double square_sum = 0.0;

  // First pass:
  //
  // output currently contains GEMM+bias.
  // Add residual in-place and collect LayerNorm statistics.
  for (
      size_t col = 0;
      col < context->n;
      ++col) {

    const float value =
        output_row[col] +
        residual_row[col];

    output_row[col] = value;

    const double value_d =
        static_cast<double>(value);

    sum += value_d;
    square_sum += value_d * value_d;
  }

  const double inv_n =
      1.0 /
      static_cast<double>(context->n);

  const double mean =
      sum * inv_n;

  double variance =
      square_sum * inv_n -
      mean * mean;

  variance =
      std::max(
          variance,
          0.0);

  const float inv_std =
      static_cast<float>(
          1.0 /
          std::sqrt(
              variance +
              static_cast<double>(
                  context->eps)));

  const float mean_f =
      static_cast<float>(mean);

  // Second pass:
  // normalize the same buffer in-place.
  for (
      size_t col = 0;
      col < context->n;
      ++col) {

    output_row[col] =
        (output_row[col] - mean_f) *
            inv_std *
            context->gamma[col] +
        context->beta[col];
  }
}

}  // namespace


extern "C" AIT_EXPORT int
{{func_name}}_prepack(
    uint64_t cache_id,
    const void* b,
    const void* bias,
    size_t n,
    size_t k) {

  if (
      n != static_cast<size_t>(
          {{prepack_n}})
      ||
      k != static_cast<size_t>(
          {{prepack_k}})) {
    return 0;
  }

  static const xnn_status init_status =
      xnn_initialize(nullptr);

  {{func_name}}_check_xnn_status(
      init_status,
      "xnn_initialize(prepack)");

  {{func_name}}_fc_cache.get(
      cache_id,
      static_cast<const float*>(b),
      static_cast<const float*>(bias),
      1,
      n,
      k);

  return 1;
}


{{func_signature}}
{
  (void)stream;

  if (
      m == 0 ||
      n == 0 ||
      k == 0) {
    return;
  }

  static const xnn_status init_status =
      xnn_initialize(nullptr);

  {{func_name}}_check_xnn_status(
      init_status,
      "xnn_initialize");

  const float* a_ptr =
      static_cast<const float*>(a);

  const float* b_ptr =
      static_cast<const float*>(b);

  const float* bias_ptr =
      static_cast<const float*>(bias);

  const float* residual_ptr =
      static_cast<const float*>(
          residual);

  const float* gamma_ptr =
      static_cast<const float*>(gamma);

  const float* beta_ptr =
      static_cast<const float*>(beta);

  float* output_ptr =
      static_cast<float*>(output);

  const float* xnn_input_ptr =
      a_ptr;

  thread_local std::vector<float>
      input_scratch;

  if (use_input_scratch) {
    const size_t input_elements =
        m * k;

    const size_t extra_elements =
        (XNN_EXTRA_BYTES +
         sizeof(float) - 1) /
        sizeof(float);

    input_scratch.resize(
        input_elements +
        extra_elements);

    std::memcpy(
        input_scratch.data(),
        a_ptr,
        input_elements *
            sizeof(float));

    std::fill(
        input_scratch.begin() +
            input_elements,
        input_scratch.end(),
        0.0f);

    xnn_input_ptr =
        input_scratch.data();
  }

  auto& context =
      {{func_name}}_fc_cache.get(
          cache_id,
          b_ptr,
          bias_ptr,
          m,
          n,
          k);

  // Critical change:
  //
  // XNNPACK writes GEMM+bias directly into the final tensor.
  // There is no m*n gemm_scratch anymore.
  if constexpr ({{func_name}}_use_int8_static_fc) {
    context.run_int8(
        xnn_input_ptr,
        output_ptr);
  } else {
      {{func_name}}_check_xnn_status(
          xnn_setup_fully_connected_nc_f32(
              context.op,
              xnn_input_ptr,
              output_ptr),
          "xnn_setup_fully_connected_nc_f32");

      {{func_name}}_check_xnn_status(
          xnn_run_operator(
              context.op,
              ait::cpu_threadpool()),
          "xnn_run_operator");
  }

  {{func_name}}_layernorm_context
      layernorm_context{
          residual_ptr,
          gamma_ptr,
          beta_ptr,
          output_ptr,
          n,
          eps};

  ait::parallelize_1d(
      {{func_name}}_layernorm_row,
      &layernorm_context,
      m);
}
"""
)


def config(
    func_attrs: Dict[str, Any],
    dtype="float32",
):
    if not _is_fused(func_attrs):
        return _BASE_CONFIG(
            func_attrs,
            dtype,
        )

    _validate_fused(func_attrs)

    func_attrs["op_instance"] = OrderedDict(
        [
            ("xnnpack", None),
        ]
    )


def gen_profiler(
    func_attrs,
    workdir,
    *args,
    **kwargs,
):
    if not _is_fused(func_attrs):
        return _BASE_GEN_PROFILER(
            func_attrs,
            workdir,
            *args,
            **kwargs,
        )

    return None


def gen_function(
    func_attrs,
    exec_cond_template=None,
    dim_info_dict=None,
):
    if not _is_fused(func_attrs):
        return _BASE_GEN_FUNCTION(
            func_attrs,
            exec_cond_template,
            dim_info_dict,
        )

    _validate_fused(func_attrs)

    a = func_attrs["inputs"][0]
    b = func_attrs["inputs"][1]
    func_name = func_attrs["name"]

    return FUNC_TEMPLATE.render(
        func_name=func_name,
        use_int8=(
            "true" if use_int8_static_fc() else "false"
        ),
        prepack_n=_dim_expr(
            b._attrs["shape"][0]
        ),
        prepack_k=_dim_expr(
            a._attrs["shape"][-1]
        ),
        func_signature=(
            FUNC_SIGNATURE.render(
                func_name=func_attrs[
                    "name"
                ]
            )
        ),
    )


def func_decl(func_attrs):
    if not _is_fused(func_attrs):
        return _BASE_FUNC_DECL(
            func_attrs
        )

    _validate_fused(func_attrs)

    return FUNC_DECL.render(
        func_signature=(
            FUNC_SIGNATURE.render(
                func_name=func_attrs[
                    "name"
                ]
            )
        )
    ).strip()


def func_call(
    func_attrs,
    indent="  ",
):
    if not _is_fused(func_attrs):
        return _BASE_FUNC_CALL(
            func_attrs,
            indent,
        )

    _validate_fused(func_attrs)

    (
        a,
        b,
        bias,
        residual,
        gamma,
        beta,
    ) = func_attrs["inputs"]

    output = func_attrs["outputs"][0]

    a_shape = a._attrs["shape"]
    b_shape = b._attrs["shape"]

    m = " * ".join(
        _dim_expr(dim)
        for dim in a_shape[:-1]
    )

    return FUNC_CALL.render(
        func_name=func_attrs["name"],
        a=a._attrs["name"],
        b=b._attrs["name"],
        bias=bias._attrs["name"],
        residual=residual._attrs["name"],
        gamma=gamma._attrs["name"],
        beta=beta._attrs["name"],
        output=output._attrs["name"],
        m=m,
        n=_dim_expr(
            b_shape[0]
        ),
        k=_dim_expr(
            a_shape[-1]
        ),
        cache_id=(
            str(
                cache_id_from_tensor_name(
                    b._attrs["name"]
                )
            )
            + "ULL"
        ),
        use_input_scratch=(
            "true"
            if _needs_input_scratch(a)
            else "false"
        ),
        eps=repr(
            float(
                func_attrs["eps"]
            )
        ) + "f",
        indent=indent,
    )


# Replace only the public registry hooks.
#
# The original functions were captured above and remain the fallback for
# ordinary, non-fused gemm_rcr_bias_add operators.
registry.BACKEND_FUNCTIONS[
    "cpu.gemm_rcr_bias_add.config"
] = config

registry.BACKEND_FUNCTIONS[
    "cpu.gemm_rcr_bias_add.gen_profiler"
] = gen_profiler

registry.BACKEND_FUNCTIONS[
    "cpu.gemm_rcr_bias_add.gen_function"
] = gen_function

registry.BACKEND_FUNCTIONS[
    "cpu.gemm_rcr_bias_add.func_decl"
] = func_decl

registry.BACKEND_FUNCTIONS[
    "cpu.gemm_rcr_bias_add.func_call"
] = func_call
